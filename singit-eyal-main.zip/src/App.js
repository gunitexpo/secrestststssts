import "./App.css";
import FirstScreen from "./screens/js/firstScreen";

function App() {
  return (
    <div className="App">
      <h1 id="logo">Singit</h1>
      <br></br>
      <FirstScreen></FirstScreen>
    </div>
  );
}

export default App;
