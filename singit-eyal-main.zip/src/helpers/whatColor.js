const whatColor = (assigment) => {
    if(assigment < 90) {
        return "#BDAADA"
    } else {
        return "#7A55B5"
    }
}

export default whatColor;